
package unidad08.U08_A04;

public enum Notas {
    DO,RE,MI,FA,SOL,LA,SI;    
}
