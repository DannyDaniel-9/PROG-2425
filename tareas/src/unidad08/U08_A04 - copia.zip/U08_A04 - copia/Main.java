
package unidad08.U08_A04;
public class Main {
    public static void main(String[] args){
        Piano yamaha = new Piano() ;
        
        yamaha.add("SI");
        yamaha.add("FA");
        yamaha.add("DO");
        yamaha.add("LA");
        yamaha.add("SI");
        
        yamaha.interpretar();

    }  
}
